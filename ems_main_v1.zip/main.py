import time
import config
from daq_interface import DAQInterface
from controller import Controller

def main():
    print(f"--- EMS 2 Record & Mimic System ---")
    print(f"Calibrated Speed: {config.LEAD_SCREW_SPEED_CMS} cm/s")
    print(f"Simulation Mode: {config.SIMULATION_MODE}")
    print("-----------------------------------\n")

    with DAQInterface(simulation=config.SIMULATION_MODE) as daq:
        ctrl = Controller()

        try:
            while True:
                print("\nREADY: Press [ENTER] to record INITIAL position of the object.")
                input()
                v_start = daq.read_sensor_voltage()
                d_start = ctrl.get_distance(v_start)
                print(f"Captured: {d_start:.2f} cm")

                print("\nMOVING: Move the object and press [ENTER] to record FINAL position.")
                input()
                v_end = daq.read_sensor_voltage()
                d_end = ctrl.get_distance(v_end)
                print(f"Captured: {d_end:.2f} cm")

                # Calculate movement requirements
                dist, direction = ctrl.calculate_displacement(v_start, v_end)
                travel_time = ctrl.get_travel_time(dist)

                print(f"\nACTION: Moving {dist:.2f} cm {direction}...")
                print(f"Estimated Time: {travel_time:.2f} seconds")
                
                # Execution
                start_time = time.time()
                while (time.time() - start_time) < travel_time:
                    # Check Limits
                    limits = daq.read_limit_switches()
                    # limits[0] is Home (Backward Limit), limits[1] is End (Forward Limit)
                    # False = Pressed
                    if (direction == "BACKWARD" and not limits[0]) or \
                       (direction == "FORWARD" and not limits[1]):
                        print(f"\n[SAFETY STOP] Hit {direction} limit switch!")
                        break
                    
                    # Apply Motor Command
                    if direction == "FORWARD":
                        daq.set_motor(True, False, True)
                    else:
                        daq.set_motor(False, True, True)
                    
                    time.sleep(0.05)
                
                daq.stop_motor()
                print("\nMovement Complete.")
                print("-" * 30)

        except KeyboardInterrupt:
            print("\nShutting down...")
            daq.stop_motor()

if __name__ == "__main__":
    main()
